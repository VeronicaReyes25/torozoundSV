
const artistCards = document.querySelectorAll('.artist-card');

artistCards.forEach(card => {
    card.addEventListener('click', () => {
        const artistName = card.querySelector('h3').innerText;
        alert(`Has hecho clic en ${artistName}`);
    });
});

